'use client'

import Konva from 'konva'
import { memo, useCallback, useEffect, useMemo, useRef } from 'react'
import { Ellipse, Group, Image as KonvaImage, Line, Path, Rect, Star, Text } from 'react-konva'
import type { KonvaEventObject } from 'konva/lib/Node'
import type {
  AnyElement,
  AudioElement,
  EmbedElement,
  FrameElement,
  GroupElement,
  ImageElement,
  LineElement,
  ShapeElement,
  StickerElement,
  StrokeElement,
  TableElement,
  TextElement,
  VideoElement,
} from '@/lib/types'
import { isLine, withAlpha, type GradientFill } from '@/lib/types'
import { elementGradientProps } from '@/lib/editor-utils'
import { useEditorStore } from '@/store/editor-store'
import { useLoadedImage } from './use-loaded-image'
import { CurvedTextNode, EmbedNode, FrameNode, TableNode, type TableCellRef } from './v06-nodes'

export interface ElementNodeProps {
  element: AnyElement
  /** editor mode: interactions enabled */
  interactive?: boolean
  /** text element currently being edited via overlay (hide the Konva text) */
  hiding?: boolean
  /** register node ref for the Transformer (editor) */
  registerNode?: (id: string, node: Konva.Node | null) => void
  /** called on every drag move so the parent can apply snapping to the node */
  onDragMoveNode?: (id: string, node: Konva.Node) => void
  /** called when a drag finishes (parent clears snapping guides) */
  onDragEndNode?: (id: string) => void
  /** double-click / double-tap (text editing; tables report the clicked cell) */
  onDoubleClick?: (id: string, cell?: TableCellRef) => void
  /** table cell currently edited via the overlay (its text is hidden underneath) */
  hideCell?: TableCellRef | null
  /** render nested (inside a group / preview) — page coords are baked by the parent */
  nested?: boolean
}

function shadowProps(el: AnyElement) {
  if (!el.shadow?.enabled) {
    return {
      shadowColor: 'transparent',
      shadowBlur: 0,
      shadowOffsetX: 0,
      shadowOffsetY: 0,
    }
  }
  return {
    shadowColor: el.shadow.color,
    shadowBlur: el.shadow.blur,
    shadowOffsetX: el.shadow.offsetX,
    shadowOffsetY: el.shadow.offsetY,
  }
}

/** canva-style text effect presets → Konva text attrs */
function textEffectProps(t: TextElement): Record<string, string | number> {
  switch (t.effect) {
    case 'shadow':
      return { shadowColor: withAlpha('#000000', 0.35), shadowBlur: 14, shadowOffsetX: 0, shadowOffsetY: 5 }
    case 'lift':
      return { shadowColor: withAlpha('#000000', 0.55), shadowBlur: 0, shadowOffsetX: 0, shadowOffsetY: 9 }
    case 'hollow':
      return { fill: 'transparent', stroke: t.fill, strokeWidth: Math.max(1, t.fontSize * 0.05), lineJoin: 'round' as unknown as string }
    case 'neon':
      return { shadowColor: t.fill, shadowBlur: 30, shadowOffsetX: 0, shadowOffsetY: 0 }
    case 'glow':
      return { shadowColor: withAlpha(t.fill, 0.85), shadowBlur: 12, shadowOffsetX: 0, shadowOffsetY: 0 }
    case 'outline':
      return { stroke: t.fill, strokeWidth: Math.max(1, t.fontSize * 0.045), lineJoin: 'round' as unknown as string }
    case 'echo':
      return { shadowColor: withAlpha(t.fill, 0.45), shadowBlur: 0, shadowOffsetX: Math.max(4, t.fontSize * 0.12), shadowOffsetY: Math.max(4, t.fontSize * 0.12) }
    case 'splice':
      return { shadowColor: withAlpha(t.fill, 0.5), shadowBlur: 0, shadowOffsetX: 0, shadowOffsetY: -Math.max(3, t.fontSize * 0.09) }
    default:
      return {}
  }
}

/** image with Konva filters (brightness / contrast / saturation) */
function ImageNode({ el, common }: { el: ImageElement; common: Record<string, unknown> }) {
  const image = useLoadedImage(el.src)
  const nodeRef = useRef<Konva.Image | null>(null)

  const bright = (el.brightness ?? 0) / 100 // konva Brighten: -0.5..0.5 approx
  const contrast = el.contrast ?? 0
  const sat = el.saturation ?? 0
  const needsFilters = bright !== 0 || contrast !== 0 || sat !== 0

  useEffect(() => {
    const node = nodeRef.current
    if (!node || !image) return
    const filters: Array<typeof Konva.Filters.Brighten> = []
    if (bright !== 0) filters.push(Konva.Filters.Brighten)
    if (contrast !== 0) filters.push(Konva.Filters.Contrast)
    if (sat !== 0) filters.push(Konva.Filters.HSL)
    node.filters(filters)
    node.brightness(bright)
    node.contrast(contrast)
    node.saturation(sat / 100)
    if (filters.length) node.cache()
    else node.clearCache()
    node.getLayer()?.batchDraw()
  }, [image, bright, contrast, sat])

  return (
    <KonvaImage
      {...common}
      ref={(n) => { nodeRef.current = n; (common.ref as (node: Konva.Node | null) => void | undefined)?.(n) }}
      image={image ?? undefined}
      width={el.width}
      height={el.height}
      cornerRadius={el.radius}
      scaleX={el.flipH ? -1 : 1}
      scaleY={el.flipV ? -1 : 1}
      offsetX={el.flipH ? el.width : 0}
      offsetY={el.flipV ? el.height : 0}
    />
  )
}

/** v0.11: audio — waveform player card. Pure vector: dark rounded card,
 *  peak bars from the baked-in analysis (so every replica renders it
 *  without the multi-MB file), a play glyph, the name, duration and a
 *  Beat Sync chip when a grid was detected. Playback happens in
 *  preview/present (see preview-stage.tsx), never in the editor canvas. */
function AudioNode({ el, common }: { el: AudioElement; common: Record<string, unknown> }) {
  const peaks = el.peaks && el.peaks.length ? el.peaks : null
  const barCount = peaks ? Math.min(peaks.length, Math.max(24, Math.floor(el.width / 6))) : 48
  const bars: number[] = []
  if (peaks) {
    for (let i = 0; i < barCount; i++) {
      bars.push(peaks[Math.floor((i / barCount) * peaks.length)] ?? 0)
    }
  }
  const barW = 3
  const gap = peaks ? Math.max(1.5, (el.width - 116 - barCount * barW) / Math.max(1, barCount - 1)) : 4
  const midY = el.height / 2

  return (
    <Group {...common} clip={undefined}>
      <Rect width={el.width} height={el.height} cornerRadius={14} fill="#1B1D27" stroke="#FFFFFF22" strokeWidth={1} />
      {/* play glyph */}
      <Path
        x={18}
        y={midY - 13}
        data="M13 0 L26 13 L13 26 Z"
        fill="#02C0CC"
      />
      {/* waveform */}
      {bars.length > 0 ? (
        bars.map((v, i) => {
          const h = Math.max(2, v * (el.height - 34))
          return (
            <Rect
              key={i}
              x={116 + i * (barW + gap)}
              y={midY - h / 2}
              width={barW}
              height={h}
              cornerRadius={1.5}
              fill="#7BE8E1"
              opacity={0.35 + 0.65 * v}
            />
          )
        })
      ) : (
        <Text x={116} y={midY - 8} text="♪" fontSize={20} fill="#7BE8E1" />
      )}
      {/* label + duration */}
      <Text
        x={18}
        y={el.height - 20}
        text={el.name.slice(0, 42)}
        fontSize={11}
        fontFamily="Inter, system-ui, sans-serif"
        fill="#FFFFFF99"
        width={el.width - 36}
        ellipsis
      />
      <Text
        x={el.width - 62}
        y={10}
        text={formatDuration(el.duration)}
        fontSize={11}
        fontFamily="Inter, system-ui, sans-serif"
        fill="#FFFFFF66"
      />
      {el.bpm ? (
        <Group x={el.width - 62} y={el.height - 21}>
          <Rect width={50} height={14} cornerRadius={7} fill="#02C0CC26" />
          <Text x={4} y={2.5} text={`${Math.round(el.bpm)} BPM`} fontSize={9} fontFamily="Inter, system-ui, sans-serif" fill="#02C0CC" />
        </Group>
      ) : null}
    </Group>
  )
}

/** v0.11: video — poster frame + play affordance + duration chip. The
 *  poster is a dataURL captured at upload, so it renders identically on
 *  every replica and in exports. Frame playback runs in preview/present. */
function VideoNode({ el, common }: { el: VideoElement; common: Record<string, unknown> }) {
  const image = useLoadedImage(el.poster)
  const isTrimmed = el.trimStart > 0.05 || el.trimEnd < el.duration - 0.05
  return (
    <Group {...common} clip={undefined}>
      <Rect width={el.width} height={el.height} cornerRadius={12} fill="#101218" />
      <KonvaImage
        image={image ?? undefined}
        x={0}
        y={0}
        width={el.width}
        height={el.height}
        cornerRadius={12}
        crop={undefined}
      />
      {/* play affordance */}
      <Group x={el.width / 2 - 24} y={el.height / 2 - 24} opacity={0.92}>
        <Ellipse radiusX={24} radiusY={24} fill="#000000AA" />
        <Path x={24 - 8} y={24 - 10} data="M0 0 L16 10 L0 20 Z" fill="#FFFFFF" />
      </Group>
      <Text
        x={el.width - 62}
        y={10}
        text={formatDuration(el.duration)}
        fontSize={11}
        fontFamily="Inter, system-ui, sans-serif"
        fill="#FFFFFFCC"
      />
      {isTrimmed && (
        <Group x={12} y={10}>
          <Rect width={44} height={14} cornerRadius={7} fill="#FFB84C26" />
          <Text x={5} y={2.5} text="TRIM" fontSize={9} fontFamily="Inter, system-ui, sans-serif" fill="#FFB84C" />
        </Group>
      )}
    </Group>
  )
}

function formatDuration(sec: number): string {
  if (!Number.isFinite(sec) || sec <= 0) return '0:00'
  const m = Math.floor(sec / 60)
  const s = Math.floor(sec % 60)
  return `${m}:${String(s).padStart(2, '0')}`
}

function ElementNodeImpl({ element: el, interactive, hiding, hideCell, registerNode, onDragMoveNode, onDragEndNode, onDoubleClick, nested }: ElementNodeProps) {
  // v0.7 rendering performance: this component no longer subscribes to the
  // editor store. Store actions are read at event time via getState(), and
  // the component is memoized (see bottom of file) — it re-renders only when
  // its own element changes identity. Combined with structural sharing in
  // the store, a keystroke or remote live edit re-renders exactly ONE node
  // instead of the whole canvas.

  // ── shared interaction handlers ────────────────────────────
  const handleClick = (e: KonvaEventObject<MouseEvent | TouchEvent>) => {
    if (!interactive) return
    e.cancelBubble = true
    const additive = !!e.evt && 'shiftKey' in e.evt && (e.evt as MouseEvent).shiftKey
    const store = useEditorStore.getState()
    if (additive) {
      store.selectToggle(el.id)
    } else {
      store.setSelection([el.id])
    }
  }

  const handleDragStart = () => {
    if (!interactive) return
    const store = useEditorStore.getState()
    store.pushHistory()
    store.setSelection([el.id])
  }

  const handleDragMove = (node: Konva.Node) => {
    if (!interactive) return
    // position is applied directly to the node; state is committed on dragEnd
    onDragMoveNode?.(el.id, node)
  }

  const handleDragEnd = (node: Konva.Node) => {
    if (!interactive) return
    const store = useEditorStore.getState()
    if (el.type === 'group') {
      // bake drag delta into children so ungroup restores the moved positions
      const g = el as GroupElement
      const dx = node.x() - g.x
      const dy = node.y() - g.y
      store.updateElementsLive([el.id], {
        x: Math.round(node.x()),
        y: Math.round(node.y()),
        children: g.children.map((c) => ({ ...c, x: Math.round(c.x + dx), y: Math.round(c.y + dy) })),
      })
      return
    }
    if (el.type === 'ellipse' || el.type === 'star') {
      store.updateElementsLive([el.id], { x: node.x() - el.width / 2, y: node.y() - el.height / 2 })
    } else {
      store.updateElementsLive([el.id], { x: node.x(), y: node.y() })
    }
  }

  const handleTransformStart = () => {
    if (!interactive) return
    const store = useEditorStore.getState()
    store.pushHistory()
    store.setSelection([el.id])
  }

  const handleTransformEnd = (node: Konva.Node) => {
    if (!interactive) return
    const store = useEditorStore.getState()
    const sx = Math.abs(node.scaleX())
    const sy = Math.abs(node.scaleY())
    // restore flip sign for images (transformer resets scale)
    if (el.type === 'image') {
      const im = el as ImageElement
      node.scaleX(im.flipH ? -1 : 1)
      node.scaleY(im.flipV ? -1 : 1)
    } else {
      node.scaleX(1)
      node.scaleY(1)
    }

    if (el.type === 'group') {
      // bake scale into children (children use page coords relative to group origin).
      // NOTE: children keep their own rotation — they render inside the rotated
      // Konva group, so adding node.rotation() here would double-rotate them.
      const g = el as GroupElement
      const dx = node.x() - g.x
      const dy = node.y() - g.y
      const children = g.children.map((c) => ({
        ...c,
        x: Math.round(g.x + dx + (c.x - g.x) * sx),
        y: Math.round(g.y + dy + (c.y - g.y) * sy),
        width: Math.max(4, c.width * sx),
        height: Math.max(4, c.height * sy),
      }))
      store.updateElementsLive([el.id], {
        children,
        x: Math.round(node.x()),
        y: Math.round(node.y()),
        width: Math.max(8, g.width * sx),
        height: Math.max(8, g.height * sy),
        rotation: node.rotation(),
      })
      return
    }

    const patch: Record<string, number> = {}

    if (el.type === 'path') {
      // paths live in a 100×100 box, scaled into place
      const newW = Math.max(8, 100 * sx)
      const newH = Math.max(8, 100 * sy)
      patch.width = newW
      patch.height = newH
      patch.x = node.x()
      patch.y = node.y()
    } else if (el.type === 'stroke') {
      // bake the scale into the point list (points are relative to x/y)
      const s = el as StrokeElement
      const scaled = s.points.map((v, i) => (i % 2 === 0 ? v * sx : v * sy))
      store.updateElementsLive([el.id], {
        points: scaled,
        strokeWidth: Math.max(1, s.strokeWidth * (sx + sy) / 2),
        rotation: node.rotation(),
        x: node.x(),
        y: node.y(),
      })
      return
    } else if (isLine(el)) {
      patch.width = Math.max(12, el.width * sx)
      patch.x = node.x()
      patch.y = node.y()
    } else if (el.type === 'text') {
      const t = el as TextElement
      patch.width = Math.max(12, el.width * sx)
      if (Math.abs(sy - 1) > 0.01) patch.fontSize = Math.max(6, t.fontSize * sy)
      patch.height = node.height() * sy
      patch.x = node.x()
      patch.y = node.y()
    } else if (el.type === 'sticker') {
      const s = el as StickerElement
      patch.fontSize = Math.max(8, s.fontSize * sy)
      patch.width = Math.max(8, el.width * sx)
      patch.height = Math.max(8, el.height * sy)
      patch.x = node.x()
      patch.y = node.y()
    } else {
      // rect / ellipse / triangle / image
      const newW = Math.max(4, el.width * sx)
      const newH = Math.max(4, el.height * sy)
      patch.width = newW
      patch.height = newH
      if (el.type === 'ellipse' || el.type === 'star') {
        patch.x = node.x() - newW / 2
        patch.y = node.y() - newH / 2
      } else {
        patch.x = node.x()
        patch.y = node.y()
      }
    }
    patch.rotation = node.rotation()
    store.updateElementsLive([el.id], patch)
  }

  // stable node ref (avoids re-register churn on every render)
  const setNodeRef = useCallback(
    (node: Konva.Node | null) => registerNode?.(el.id, node),
    [registerNode, el.id]
  )

  const common = {
    id: el.id,
    name: 'cv-element',
    x: el.x,
    y: el.y,
    rotation: el.rotation,
    opacity: el.opacity,
    visible: el.visible && !hiding,
    draggable: interactive && !el.locked,
    // v0.7: skip Konva's "perfect draw" hit-canvas pass — big win while
    // dragging/transforming, no visible change for our node types.
    perfectDrawEnabled: false,
    onClick: handleClick,
    onTap: handleClick,
    onDragStart: handleDragStart,
    onDragMove: (e: KonvaEventObject<DragEvent>) => handleDragMove(e.target),
    onDragEnd: (e: KonvaEventObject<DragEvent>) => {
      handleDragEnd(e.target)
      onDragEndNode?.(el.id)
    },
    onTransformStart: handleTransformStart,
    onTransformEnd: (e: KonvaEventObject<Event>) => handleTransformEnd(e.target),
    onDblClick: () => interactive && onDoubleClick?.(el.id),
    onDblTap: () => interactive && onDoubleClick?.(el.id),
    ref: setNodeRef,
    ...shadowProps(el),
  }

  const { curve = 0 } = el as TextElement
  if (el.type === 'text' && curve !== 0) {
    // v0.6: curved text (single-line arc — effects fall back to plain fill)
    const t = el as TextElement
    return <CurvedTextNode t={t} common={common} />
  }

  switch (el.type) {
    case 'text': {
      const t = el as TextElement
      const effect = t.effect && t.effect !== 'none' ? textEffectProps(t) : {}
      const rendered = t.uppercase ? t.text.toUpperCase() : t.text
      // gradient fill (skipped for effects that own the fill, e.g. Hollow)
      const textGrad: GradientFill | null | undefined = t.fillGradient
      const gradProps =
        textGrad && (!t.effect || ['none', 'shadow', 'lift', 'echo', 'splice'].includes(t.effect))
          ? elementGradientProps(textGrad, t.width, Math.max(t.height, t.fontSize * t.lineHeight), 'corner')
          : {}

      if (t.effect === 'background') {
        // canva "Background" effect: solid block behind the text
        const bg = t.effectBackground ?? '#EFEFEF'
        const h = Math.max(t.height, t.fontSize * t.lineHeight + 8)
        return (
          <Group {...common}>
            <Rect width={t.width} height={h} fill={bg} cornerRadius={Math.min(8, t.fontSize * 0.2)} />
            <Text
              text={rendered}
              fontSize={t.fontSize}
              fontFamily={t.fontFamily}
              fontStyle={`${t.italic ? 'italic ' : ''}${t.bold ? 'bold' : 'normal'}`}
              textDecoration={[t.underline ? 'underline' : '', t.strike ? 'line-through' : ''].filter(Boolean).join(' ')}
              fill={t.fill}
              align={t.align === 'justify' ? 'left' : t.align}
              width={t.width}
              lineHeight={t.lineHeight}
              letterSpacing={t.letterSpacing}
              wrap="word"
              perfectDrawEnabled={false}
              ref={() => undefined}
            />
          </Group>
        )
      }

      if (t.effect === 'splice') {
        // canva "Splice": sliced look — ghost copies above & below
        return (
          <Group {...common}>
            <Text text={rendered} fontSize={t.fontSize} fontFamily={t.fontFamily} fontStyle={`${t.italic ? 'italic ' : ''}${t.bold ? 'bold' : 'normal'}`} fill={withAlpha(t.fill, 0.35)} align={t.align === 'justify' ? 'left' : t.align} width={t.width} lineHeight={t.lineHeight} letterSpacing={t.letterSpacing} wrap="word" y={-Math.max(3, t.fontSize * 0.09)} perfectDrawEnabled={false} />
            <Text text={rendered} fontSize={t.fontSize} fontFamily={t.fontFamily} fontStyle={`${t.italic ? 'italic ' : ''}${t.bold ? 'bold' : 'normal'}`} fill={withAlpha(t.fill, 0.35)} align={t.align === 'justify' ? 'left' : t.align} width={t.width} lineHeight={t.lineHeight} letterSpacing={t.letterSpacing} wrap="word" y={Math.max(3, t.fontSize * 0.09)} perfectDrawEnabled={false} />
            <Text text={rendered} fontSize={t.fontSize} fontFamily={t.fontFamily} fontStyle={`${t.italic ? 'italic ' : ''}${t.bold ? 'bold' : 'normal'}`} fill={t.fill} align={t.align === 'justify' ? 'left' : t.align} width={t.width} lineHeight={t.lineHeight} letterSpacing={t.letterSpacing} wrap="word" perfectDrawEnabled={false} />
          </Group>
        )
      }

      return (
        <Text
          {...common}
          {...effect}
          {...gradProps}
          text={rendered}
          fontSize={t.fontSize}
          fontFamily={t.fontFamily}
          fontStyle={`${t.italic ? 'italic ' : ''}${t.bold ? 'bold' : 'normal'}`}
          textDecoration={[t.underline ? 'underline' : '', t.strike ? 'line-through' : ''].filter(Boolean).join(' ')}
          fill={Object.keys(gradProps).length ? undefined : t.fill}
          align={t.align === 'justify' ? 'left' : t.align}
          width={t.width}
          lineHeight={t.lineHeight}
          letterSpacing={t.letterSpacing}
          wrap="word"
          perfectDrawEnabled={false}
        />
      )
    }

    case 'rect': {
      const s = el as ShapeElement
      const grad = s.fillGradient ? elementGradientProps(s.fillGradient, s.width, s.height, 'corner') : {}
      return <Rect {...common} width={s.width} height={s.height} {...grad} fill={s.fillGradient ? undefined : s.fill} stroke={s.stroke} strokeWidth={s.strokeWidth} cornerRadius={s.cornerRadius} />
    }

    case 'ellipse': {
      const s = el as ShapeElement
      const grad = s.fillGradient ? elementGradientProps(s.fillGradient, s.width, s.height, 'center') : {}
      return <Ellipse {...common} x={s.x + s.width / 2} y={s.y + s.height / 2} radiusX={s.width / 2} radiusY={s.height / 2} {...grad} fill={s.fillGradient ? undefined : s.fill} stroke={s.stroke} strokeWidth={s.strokeWidth} />
    }

    case 'triangle': {
      const s = el as ShapeElement
      const grad = s.fillGradient ? elementGradientProps(s.fillGradient, s.width, s.height, 'corner') : {}
      return <Line {...common} points={[0, s.height, s.width / 2, 0, s.width, s.height]} closed {...grad} fill={s.fillGradient ? undefined : s.fill} stroke={s.stroke} strokeWidth={s.strokeWidth} />
    }

    case 'star': {
      const s = el as ShapeElement
      const outer = Math.min(s.width, s.height) / 2
      const grad = s.fillGradient ? elementGradientProps(s.fillGradient, s.width, s.height, 'center') : {}
      return <Star {...common} x={s.x + s.width / 2} y={s.y + s.height / 2} numPoints={5} innerRadius={outer * 0.55} outerRadius={outer} {...grad} fill={s.fillGradient ? undefined : s.fill} stroke={s.stroke} strokeWidth={s.strokeWidth} />
    }

    case 'path': {
      const s = el as ShapeElement
      const grad = s.fillGradient ? elementGradientProps(s.fillGradient, s.width, s.height, 'box100') : {}
      return <Path {...common} data={s.pathData ?? ''} scaleX={s.width / 100} scaleY={s.height / 100} {...grad} fill={s.fillGradient ? undefined : s.fill} stroke={s.stroke} strokeWidth={s.strokeWidth / (s.width / 100)} />
    }

    case 'line': {
      const l = el as LineElement
      const points = [0, 0, Math.max(l.width, 12), 0]
      const shared = {
        ...common,
        x: l.x,
        y: l.y,
        points,
        stroke: l.stroke,
        strokeWidth: l.strokeWidth,
        lineCap: 'round' as const,
        dash: l.dashed ? [l.strokeWidth * 2.2, l.strokeWidth * 1.8] : undefined,
      }
      if (l.arrowStart || l.arrowEnd) {
        return (
          <Line
            {...shared}
            fill={l.stroke}
            pointerLength={Math.max(10, l.strokeWidth * 2.4)}
            pointerWidth={Math.max(8, l.strokeWidth * 2)}
            pointerAtBeginning={l.arrowStart}
            pointerAtEnd={l.arrowEnd}
          />
        )
      }
      return <Line {...shared} hitStrokeWidth={Math.max(12, l.strokeWidth)} />
    }

    case 'stroke': {
      const s = el as StrokeElement
      return (
        <Line
          {...common}
          points={s.points}
          stroke={s.stroke}
          strokeWidth={s.strokeWidth}
          lineCap="round"
          lineJoin="round"
          tension={0.25}
          hitStrokeWidth={Math.max(14, s.strokeWidth)}
        />
      )
    }

    case 'image': {
      const im = el as ImageElement
      return <ImageNode el={im} common={common} />
    }

    case 'audio': {
      const au = el as AudioElement
      return <AudioNode el={au} common={common} />
    }

    case 'video': {
      const vd = el as VideoElement
      return <VideoNode el={vd} common={common} />
    }

    case 'table': {
      const tb = el as TableElement
      return (
        <TableNode
          el={tb}
          common={common}
          interactive={interactive}
          onCellDoubleClick={(cell) => interactive && onDoubleClick?.(el.id, cell)}
          hideCell={hideCell ?? null}
        />
      )
    }

    case 'frame': {
      const fr = el as FrameElement
      return <FrameNode el={fr} common={common} />
    }

    case 'embed': {
      const em = el as EmbedElement
      return <EmbedNode el={em} common={common} />
    }

    case 'sticker': {
      const sk = el as StickerElement
      return <Text {...common} text={sk.char} fontSize={sk.fontSize} fontFamily="'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', sans-serif" width={sk.width} height={sk.height} align="center" />
    }

    case 'group': {
      const g = el as GroupElement
      return (
        <Group {...common} clip={undefined}>
          {g.children
            .filter((c) => c.visible)
            .map((c) => (
              <ElementNode
                key={c.id}
                element={{ ...c, x: c.x - g.x, y: c.y - g.y } as AnyElement}
                interactive={false}
                nested
              />
            ))}
        </Group>
      )
    }

    default: {
      // exhaustive: every ElementType is handled above
      return null
    }
  }
}

/**
 * v0.7 rendering performance: memoized canvas element node. With structural
 * sharing in the editor store, untouched elements keep referential identity,
 * so a mutation re-renders only the nodes whose elements actually changed.
 */
export const ElementNode = memo(ElementNodeImpl)

/** non-interactive renderer used inside thumbnails / previews */
export const PreviewElements = memo(function PreviewElements({ elements }: { elements: AnyElement[] }) {
  const reg = useCallback(() => undefined, [])
  return (
    <Group listening={false}>
      {elements.map((el) => (
        <ElementNode key={el.id} element={el} interactive={false} registerNode={reg} />
      ))}
    </Group>
  )
})
